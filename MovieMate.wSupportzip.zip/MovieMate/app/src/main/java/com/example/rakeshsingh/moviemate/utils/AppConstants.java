package com.example.rakeshsingh.moviemate.utils;

public class AppConstants {
    public final static String API_KEY="31ff2f1ac310aab99cd32cc7805c198c";
    public final static String BASE_URL = "https://api.themoviedb.org/3/";
    public final static String POPULAR = "popular";
    public final static String TOP_RATED = "top_rated";
    public final static String FAVORITES= "favorites";
}
